# Bar to Blade

**Version 1.12.1** · [Changelog](versions/CHANGELOG.md)

**A free bar stock calculator and blade planner for bladesmiths.**

Enter the steel on your bench and Bar to Blade shows which blades it can make. It covers 88 traditional weapons, and each has a to-scale drawing, target dimensions and a printable spec sheet. You can also track your stock and projects, and trace your own designs to work out the steel they need.

Bar to Blade is one HTML file. It needs no install, no account and no server, and runs in any modern browser on desktop or phone.

---

## Features

### Calculator
- Enter your bar's shape (square, hex, round or flat), size and length, in inches or millimeters.
- Inch values show as fractions (1 1/4, 3/8) and you can type them that way.
- Choose a scale loss (5% to 20%) to match how you forge.
- See the biggest blade your bar makes, how much steel is left over, and how much more you'd need for the next one up.
- A row of 12 blades your bar makes, with thumbnails: the largest first, the smallest last, and 10 recommended picks in between.

### Blade Library
- 88 blades: 44 swords, 20 knives and machetes, 9 polearm heads and 15 other weapons (darts, spikes, hammers, chains).
- They come from Japan, China, Europe (including Oakeshott types X to XVIII), the Middle East, South and Southeast Asia, the Philippines, Africa and the Americas.
- Every blade is marked **Fits**, **Close** or **Needs more** against your bar.
- Each blade has:
  - a thumbnail in the list and a to-scale drawing;
  - a full dimension table with sources;
  - where to mark the shoulder on your bar;
  - a one-page spec sheet you can print.
- Filter by region or type, or search by name or alternate name.
- **Tang: Hidden or Full** on knives and machetes where a full tang makes sense. A full tang follows the handle outline, so the steel needed, drawing and spec sheet update.
- **Fullers: Ground in or Forged in.** Forged fullers move steel instead of grinding it away. This switch adjusts the steel needed and shows the narrower blank width to forge before fullering.

### My Shop
- Keep a stock rack with an ID for each bar (paint it on the steel).
- Start projects from any blade with numbered IDs (P-001, P-002) and assign a bar to each one.
- Bars reserved for a project or already used are greyed out on the rack.
- A demo rack of salvaged steel shows how it works: railroad pigtails, leaf springs, mower blades and cable.

### Design Studio
- Trace a blade from a photo or a drawing on graph paper, or import SVG, DXF, STL or OBJ files.
- Add as many bevel lines as you need, each with a type (primary bevel, secondary bevel, false edge, fuller edge), shown on the drawing and spec sheet.
- Set the real size, turn on a grid overlay, and get the steel volume, the best starting bar and a spec sheet.
- Saved designs appear in the Blade Library marked **Custom**.

### Guide & Methods
- Step-by-step instructions, plus how the volume, scale loss and bar layout math works.

---

## Getting started

1. Download `index.html`.
2. Open it in Chrome, Edge, Firefox or Safari.
3. Enter your bar in the **Calculator** tab, then open the **Blade Library**.

To put it online, upload `index.html` to any static host: GitHub Pages, Netlify, or your own web server.

### GitHub Pages
1. Put `index.html` in the root of your repository.
2. Go to **Settings > Pages**.
3. Choose your main branch and the root folder, then save.
4. Your site will be at `https://<your-username>.github.io/<repo-name>/`.

---

## Your data and backups

> **Important:** everything you save is kept in your browser on that device. Nothing is sent to a server.

That includes your stock, projects, saved designs and settings. This keeps the tool private and working offline, but your data can be lost if:
- you clear your browser's cookies and site data;
- you use a private or incognito window;
- Safari removes data for a site you haven't visited in about a week;
- you open the file from a different folder or in a different browser.

**Protect your work with backup files:**
- **My Shop > Export backup** saves everything to `bar-to-blade-shop.json`.
- **My Shop > Import** brings it back on this or any other computer.
- The page reminds you: an orange **Not backed up** bar appears when you have changes, it asks to save a backup after you save a design, and the browser warns you if you close the page with unsaved changes.

---

## How the math works

| Step | What it does |
|---|---|
| Bar volume | Cross-section area × length |
| Usable steel | Bar volume × (1 − scale loss) |
| Steel needed | The forged preform (blade + tang) with grinding allowance; pairs count both pieces, and polearms and hammers count the head only |
| Bar layout | Blade and tang steel ÷ usable steel per inch of bar gives where to mark the shoulder, measured from the tip end |
| Forged fuller | Removes the groove volume (fuller length × width × depth × 2/3, both sides) from the steel needed |

Weights use 0.284 lb/in³ (7.85 g/cm³) for carbon steel.

---

## Accuracy

Dimensions are typical figures for each type, taken from museum pieces, antiques, reproductions and published typologies. Real swords and knives vary, so treat each spec sheet as a starting point. Each blade lists its sources on its dimension table.

Test unknown or salvaged steel (spark test, or harden and snap an offcut) before committing a big blade to it.

---

## Suggest a blade

Missing a blade from your tradition? Use the **Suggest a blade** button on the page to send its name and dimensions.

---

## Built with

- Plain HTML, CSS and JavaScript in one file, with no frameworks and no build step required.
- Fonts: Barlow Condensed, Inter and JetBrains Mono (Google Fonts).

---

## License

Add the license you want here, for example MIT. Without one, others can view the code but have no permission to reuse it.

---

Made for bladesmiths by Michael Krawczyk.
