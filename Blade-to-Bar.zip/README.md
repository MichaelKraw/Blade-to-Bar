# Bar to Blade

**Version 1.38** · [Changelog](versions/CHANGELOG.md)

**A free bar stock calculator and blade planner for bladesmiths.**

Enter the steel on your bench and Bar to Blade shows which blades it can make. It covers 127 traditional weapons, and each has a to-scale drawing, target dimensions and a printable spec sheet. You can also track your stock and projects, and trace your own designs to work out the steel they need.

Bar to Blade is one HTML file. It needs no install, no account and no server, and runs in any modern browser on desktop or phone.

---

## Features

### Calculator
- Enter your bar's shape (square, hex, round or flat), size and length, in inches or millimeters.
- Inch values show as fractions (1 1/4, 3/8) and you can type them that way.
- Choose a scale loss (5% to 20%) to match how you forge.
- See the biggest blade your bar makes, how much steel is left over, and how much more you'd need for the next one up.
- A row of 12 blades your bar makes, with thumbnails: the largest first, the smallest last, and 10 recommended picks in between.

### Blade Library
- 127 weapons: swords, knives, daggers and machetes, polearm heads, and other weapons (maces, hammers, darts, chains).
- They come from Japan, China, Europe (including Oakeshott types X to XVIII), the Middle East, South and Southeast Asia, the Philippines, Africa and the Americas.
- Every blade is marked **Fits**, **Close** or **Needs more** against your bar.
- Click a column heading to sort by name, origin, blade length, steel needed, billet, coverage or result (a Sort menu on phones).
- Each blade has:
  - a thumbnail in the list and a to-scale drawing;
  - a full dimension table with sources;
  - where to mark the shoulder on your bar;
  - a one-page spec sheet you can print.
- Filter by region or type, or search by name or alternate name.
- **Customize this blade** (in a blade's details) opens it in Blade Refinement to reshape and save as your own design. Left unrenamed, it saves as "Blade name - custom".
- **Tang: Hidden or Full** on knives and machetes where a full tang makes sense. A full tang follows the handle outline, so the steel needed, drawing and spec sheet update.
- **Fullers: Ground in or Forged in.** Forged fullers move steel instead of grinding it away. This switch adjusts the steel needed and shows the narrower blank width to forge before fullering.

### My Shop
- Keep a stock rack with an ID for each bar (paint it on the steel).
- Start projects from any blade with numbered IDs (P-001, P-002) and assign a bar to each one.
- Bars reserved for a project or already used are greyed out on the rack.
- A demo rack of salvaged steel shows how it works: railroad pigtails, leaf springs, mower blades and cable.

### Design Studio
- Trace a blade from a photo or a drawing on graph paper, or import SVG, DXF, STL or OBJ files.
- Add as many bevel lines as you need, each with a type (primary bevel, secondary bevel, false edge, fuller edge), shown on the drawing and spec sheet.
- Set the real size, turn on a grid overlay, and get the steel volume, the best starting bar and a spec sheet.
- Smooth curves through your points (sharp corners like the tip and shoulder stay sharp).
- Crop the photo down to the blade, rotate a crooked photo to level (drag, slider, 90 degree turns, or Level my trace), and hold Shift to keep lines straight while tracing.
- Saved designs appear in the Blade Library marked **Custom**.

### Guards and hilts
- Pick a library blade or one of your designs; every guard is sized to its blade width, tang and grip. You can adjust any size.
- 26 types. Simple: straight, curved and S-shaped quillons, Viking short guard, tsuba, single front, double, integral and half bolsters, guardless with a choil, and short stub guard. Intermediate: knuckle bow, side-ring, clamshell, D-guard, Pappenheimer, langet, bird's-beak, block, drop quillon and single finger guard. Complex: swept, basket, cup, half-basket and finger-ring hilts.
- Listed like the Blade Library: filter by build (Simple, Intermediate, Complex), search, sort by any column, and click a guard for its drawing, parts, how-to notes and sources.
- Each prints a stock list and 1:1 templates: cut outlines with the tang slot, and flat bars with bend marks for hilts built from rods. Long parts split across pages. Print at Actual size and check the 1 in square.

### Shields
- 12 shields: round (Viking), Anglo-Saxon round, oval, kite, heater, bouche heater, pavise, rectangular infantry, mantlet, buckler, rondache and Scottish targe.
- Listed like the Blade Library: filter by build (Beginner, Intermediate, Advanced), search, and sort by era, size, steel, rivets or weight.
- Set the size and board thickness of any shield to get its steel parts (boss, grip, back straps, rim or steel face) with stock and cut sizes, rivets by location with lengths, and the wood, steel and total weight.
- Build sheet prints the parts, rivets, build steps and sources, with a 1:1 boss blank template (rivet holes marked).
- Sizes come from surviving shields and museum records (Gokstad, Sutton Hoo, the Met, Cleveland and others).

### Blade Refinement
- Photograph the blade you are forging, trace it in the Design Studio and save it. It opens with the blade **as forged** on the left and the same points on the right to refine.
- Drag points, tap the outline to add one, and remove one with a double-click or Delete. Undo and Start over are there too.
- The steel to grind off is shaded, anything outside your forging shows red, and the new length, width and steel removed update as you work.
- **What this forging could become** fits every library blade inside your as-forged outline at its normal size and ranks them by how much of the forging they use. Load one as the refined shape and fine-tune it.
- **Handle scales and pins:** add pins to the tang (a new pin centers), let Auto offset space two or more evenly, or drag them where you want. Pins save with the design, and Pin template & stock sheet prints a 1:1 drill template for the tang and scales with pin positions and pin stock.
- Once refined, the design's spec sheet gives the refined blade's specs (size, steel, bars and fit) with the as-forged numbers alongside. Refinements also go into your backup file.

### Guide & Methods
- Step-by-step instructions, plus how the volume, scale loss and bar layout math works.

---

## Ironwork

Household, farm, everyday and personal ironwork, the easiest place to start forging. 39 pieces in ten groups: hardware (drive hook, strap hinge and pintle, hasp and staple, door pull, thumb latch, slide bolt), hearth and kitchen (S-hook, flesh fork, ladle, skimmer, trammel, trivet, campfire tripod, andirons), lighting (rushlight holder, spiral candle holder), locks and keys (warded key, warded chest lock), farm and farrier (horseshoe sizes 000 to 3, hand-forged chain with hook) garden (hoe, rake, trowel), buckles and pins (Roman, medieval and colonial buckles, Viking strap end, penannular brooch, ringed pin, disc brooch), jewelry (finger ring by US ring size, Viking twisted arm ring, cuff bracelet), seals and stamps (personal seal matrix, maker's mark stamp) and desk and bar (bottle opener, T-handle corkscrew, letter opener, pen tray). Laid out like the Blade Library, with filters, search and sorting. Each piece has a scale drawing, an editable main size, a stock and cut list, steel weight, steps and museum sources, plus a printable build sheet with a 1:1 template where it fits on paper.

## Scale Builder

Build handle scales from a photo of your blank. Set the scale from a ruler in the photo (or type the handle length), trace the handle, and drop a pin over each hole (up to 6). A pin bar centers the pins you pick on the handle's center line or offsets them with a slider or arrows, and Stagger alternates them up and down. Optional step 4, Blocks, splits the outside scale along the handle into up to 9 blocks: a bolster, the main scale, angled spacers, an end cap. Click to add joints, drag to slide or angle them, or start from a quick layout; each block has its own material, colour, length and joint angle, and pins that land on a joint are flagged. A camera button on each block loads a photo of your material; drag, zoom and rotate it to crop in on the look you want, and it shows on the handle and the spec sheet. Stack up to five layers per side (liners, spacers, bolster plates, the scale) for the total thickness, pin length and weight. Builds save to My Shop and the backup, and the spec sheet prints the outline with blocks and pins, the layer and block cut lists, build steps and a 1:1 template.

## Heat Treat

Forge-to-temper heat treat steps for 14 forging steels: 1075, 1080/1084, 1095, 26C3, W1, W2, 15N20, 5160, 52100, 80CrV2, 8670, CruForge V, O1 and L6. Each steel shows forging, normalizing and annealing, hardening (austenitize and soak), quench and temper, with a temper-to-hardness table where a source gives one, composition and an ease rating. Every value is numbered to its source (Kevin Cashen's working sequences, Larrin Thomas's Knife Steel Nerds tests, supplier sheets and mill datasheets), and missing data is marked instead of guessed. Tools: a soak calculator, a temper timer that counts each cycle and beeps, and a Damascus and san mai pairing check. Each steel prints as a heat treat card. Heat by eye: glow and temper colour ladders mark each steel's forging, normalizing, hardening and tempering heats plus the magnet test point, and every step carries colour chips, so the tab works without a thermometer.

## Getting started

1. Download `index.html`.
2. Open it in Chrome, Edge, Firefox or Safari.
3. Enter your bar in the **Calculator** tab, then open the **Blade Library**.

To put it online, upload `index.html` to any static host: GitHub Pages, Netlify, or your own web server.

### GitHub Pages
1. Put `index.html` in the root of your repository.
2. Go to **Settings > Pages**.
3. Choose your main branch and the root folder, then save.
4. Your site will be at `https://<your-username>.github.io/<repo-name>/`.

---

## Your data and backups

> **Important:** everything you save is kept in your browser on that device. Nothing is sent to a server.

That includes your stock, projects, saved designs and settings. This keeps the tool private and working offline, but your data can be lost if:
- you clear your browser's cookies and site data;
- you use a private or incognito window;
- Safari removes data for a site you haven't visited in about a week;
- you open the file from a different folder or in a different browser.

**Protect your work with backup files:**
- **My Shop > Export backup** saves everything to `bar-to-blade-shop.json`.
- **My Shop > Import** brings it back on this or any other computer.
- The page reminds you: an orange **Not backed up** bar appears when you have changes, it asks to save a backup after you save a design, and the browser warns you if you close the page with unsaved changes.

---

## How the math works

| Step | What it does |
|---|---|
| Bar volume | Cross-section area × length |
| Usable steel | Bar volume × (1 − scale loss) |
| Steel needed | The forged preform (blade + tang) with grinding allowance; pairs count both pieces, and polearms and hammers count the head only |
| Bar layout | Blade and tang steel ÷ usable steel per inch of bar gives where to mark the shoulder, measured from the tip end |
| Forged fuller | Removes the groove volume (fuller length × width × depth × 2/3, both sides) from the steel needed |

Weights use 0.284 lb/in³ (7.85 g/cm³) for carbon steel.

---

## Accuracy

Dimensions are typical figures for each type, taken from museum pieces, antiques, reproductions and published typologies. Real swords and knives vary, so treat each spec sheet as a starting point. Each blade lists its sources on its dimension table.

Test unknown or salvaged steel (spark test, or harden and snap an offcut) before committing a big blade to it.

---

## Suggest a blade

Missing a blade from your tradition? Use the **Suggest a blade** button on the page to send its name and dimensions.

---

## Built with

- Plain HTML, CSS and JavaScript in one file, with no frameworks and no build step required.
- Fonts: Barlow Condensed, Inter and JetBrains Mono (Google Fonts).

---

## License

Add the license you want here, for example MIT. Without one, others can view the code but have no permission to reuse it.

---

Made for bladesmiths by Michael Krawczyk.
