# Bar to Blade changelog

Current version: **v1.14**

When you release a change, add a new section at the top, bump the version badge in `index.html` (search for `class="ver"`), and add the same entry to the Version history list in the Guide & Methods tab.

## v1.14 (Nov 14, 2026)

12 weapons from the Forged in Fire list (107 in all): Khanda, Nagamaki, Panabas, Katar, Falcata, Zulu Iklwa, Tizona (El Cid's sword), US M1913 Patton Saber, US M1905 Bayonet, Maguro Bocho (tuna knife), Zulu War Axe (isizenze) and Zande Sickle Sword (Boa). Searching zhanmadao, Viking battle axe, okatana or arming sword finds the blades already listed. Passed: Okatana (a katana variant with no set size), Sword of Perseus and Genghis Khan's Sword (legendary, no surviving pieces to measure) and the French Pioneer Sword (no reliable measurements found).

## v1.13 (Nov 14, 2026)

Seven more Chinese weapons (95 in all): Tie Jian (iron mace), Tie Bian (iron whip), Tie Chi (iron ruler), Ge (dagger-axe), Cha (trident fork), Yue Ya Chan (monk's spade) and Chui (melon hammer). Chinese names added so searching hu die dao, zi-wu, jie bian, emei ci, liu xing chui or rope dart finds the blades already listed.

## v1.12.1 (Nov 14, 2026)

Bevel lines panel in the Design Studio: + Add bevel line is always visible, every line is listed with its own Delete button, and each line has a type (primary bevel, secondary bevel, false edge, fuller edge or other) with its own color and dash style on the drawing and spec sheet.

## v1.12 (Nov 14, 2026)

Design Studio step 4: Bevel lines. Click along each grind line (both sides, secondary bevels, a false edge or fuller edges); New bevel line starts the next one. They show dashed on the saved design, in the Blade Library and on the spec sheet, and come back when you reopen the design.

## v1.11.2 (Nov 14, 2026)

Design Studio: no ruler in the photo? Type the blade length (tip to shoulder) to set the scale. Save design and Spec sheet now say exactly what is missing instead of doing nothing.

## v1.11.1 (Nov 14, 2026)

Smaller tracing dots in the Design Studio, and a smaller grab zone so you can place points close together. Touch screens keep a slightly larger zone for fingers.

## v1.11 (Nov 14, 2026)

Hidden tang or Full tang switch on knives and machetes where a full tang makes sense: Clip-point Hunter, Hunting Bowie, Bolo, Kukri, Parang, Latin Machete, Cane Machete, Barong, Golok and Karambit. It updates the steel needed, the drawing, the dimensions and the spec sheet. Your choice is remembered per blade.

## v1.10 (Nov 14, 2026)

Calculator shows 12 blades your bar makes, with thumbnails: the largest first, the smallest last, and 10 recommended picks in between (good use of the steel with the least reshaping). Click any one to open it in the Blade Library.

## v1.9.1 (Nov 14, 2026)

Project notes can be edited on each project card and print on the project's spec sheet.

## v1.9 (Nov 12, 2026)

Backup reminders: a Not backed up bar, a prompt to save a backup file after saving a design, and a warning before closing with unsaved changes.

## v1.8 (Nov 12, 2026)

Tabbed layout (Calculator, My Shop, Design Studio, Blade Library, Guide & Methods). Saved designs appear in the Blade Library marked Custom, with a Custom filter.

## v1.7 (Nov 12, 2026)

23 new weapons (88 in all): Tang, Qijiebian, Yue, Tekko-kagi, Kama, Kunai, Shuriken, Sai, Manriki-gusari, Rapier, Flanged Mace, Military Flail, Horseman's War Hammer, Dane Axe, Winged Spear, Keris, Moro Kris, Badik, Karambit, Rencong, Golok, Ginunting and Klewang.

## v1.6 (Nov 10 to 12, 2026)

Thumbnails of every blade in the list. Full dimensions for the Kogatana, Kaiken, Ko-wakizashi and Bishou.

## v1.5 (Nov 10, 2026)

Oakeshott types X, Xa, XI, XII, XIII, XIIIa, XIV, XV, XVI and XVIII. Fullers: Ground in or Forged in switch with preform width (from Brent's feedback).

## v1.4 (Before Nov 10, 2026)

Realistic outlines for every blade. Closed-outline tracing, grid overlay, saved designs with automatic spec sheets, and a how-to guide. US 1826 Starr Naval Cutlass and Buck 119/120 style knives.

## v1.3 (Before Nov 10, 2026)

My Shop: stock rack with painted IDs, projects with P-numbers, reserved and used bars greyed out, and a demo rack of salvaged steel.

## v1.2 (Before Nov 10, 2026)

Plan from a drawing: trace a photo or graph paper, or import SVG, DXF, STL or OBJ, with a real-size control.

## v1.1 (Before Nov 10, 2026)

Inch fractions, tighter layout, and Suggest a blade through Microsoft Forms.

## v1.0 (Before Nov 10, 2026)

First release: bar stock calculator, blade library with drawings and dimensions, and printable spec sheets.
