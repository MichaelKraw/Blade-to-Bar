# Bar to Blade changelog

Current version: **v1.34**

When you release a change, add a new section at the top, bump the version badge in `index.html` (search for `class="ver"`), and add the same entry to the Version history list in the Guide & Methods tab.

## v1.34 (Nov 17, 2026)

- New Scale Builder tab for handle scales. Upload a photo of your blank with a ruler in frame, set the scale, trace the handle and click to drop a pin over each hole (up to 6). Rotate levels a crooked photo, Smooth curves the outline, and Flip front sets which end meets the guard.
- Stack up to 5 layers on each side, starting against the tang (liners, spacers, bolster plates and the scale), each with its own material and thickness. Uncheck Same on both sides to build each side differently.
- Live totals: handle length and width, total handle thickness, pin length, scales weight from typical material densities, and a to-scale cross-section of the stack.
- No photo? Start from a saved design's tang, or try the sample blank.
- Save builds to My handle builds (H-001, H-002 and so on). They keep the outline, pins and layers (not the photo) and go into your backup file.
- Scale spec sheet: outline to scale with numbered pins, the layer stack and cut list, the cross-section, pin positions from the front and both edges, pin stock and length, build steps, and a 1:1 outline template with the pin holes.

## v1.33 (Nov 16, 2026)

- Ironwork: 16 decorative and personal pieces in four new groups (39 pieces in all). Buckles and pins: Roman belt buckle and plate, medieval D buckle, colonial harness buckle, Viking strap end, penannular brooch, Viking ringed pin and disc brooch. Jewelry: forged finger ring (pick a US ring size and the cut length is worked out for you), Viking twisted arm ring and forged cuff bracelet. Seals and stamps: personal seal matrix and maker's mark stamp. Desk and bar: bottle opener, T-handle corkscrew, letter opener and pen tray. Small pieces show their weight in ounces (grams in metric), and every one prints a 1:1 template.

## v1.32 (Nov 16, 2026)

- Ironwork tab: 23 household, farm and everyday pieces (hooks, strap hinge and pintle, hasp, door pull, thumb latch, slide bolt, flesh fork, ladle, skimmer, trammel, trivet, campfire tripod, andirons, rushlight, spiral candle holder, warded key and chest lock, horseshoe, chain, hoe, rake and trowel). Each piece has a drawing, an editable main size, a stock and cut list, steel weight, steps, museum sources and a build sheet with a 1:1 template where it fits on paper.

## v1.31 (Nov 16, 2026)

Seven European polearm heads added (127 in all): English Bill, Partisan, Glaive, Bardiche, Lucerne Hammer, Bec de Corbin and Poleaxe, sized from the Met, the Moscow Kremlin Museums, the Worcester Art Museum, the Higgins Armory poleaxe and Arms & Armor replicas of museum pieces. Heads only; the socket or langets are listed as the tang and the shaft is not counted.

## v1.30 (Nov 16, 2026)

Eight European daggers and the seax added (120 in all): Rondel Dagger, Ballock Dagger, Quillon Dagger, Baselard (with the Hidden or Full tang switch), Cinquedea, Stiletto, Main Gauche and the Langseax (broken-back), sized from the British Museum, the Met, the Fitzwilliam, Cleveland and other surviving pieces. Each has a to-scale drawing, target dimensions with sources, a spec sheet and Customize this blade.

## v1.29 (Nov 16, 2026)

New Shields tab, laid out like the Blade Library: 12 shields (round, Anglo-Saxon round, oval, kite, heater, bouche heater, pavise, rectangular infantry, mantlet, buckler, rondache and Scottish targe) with build level, era, size, steel parts, rivet count and total weight. Filter by Beginner, Intermediate or Advanced, search, and sort any column. Click a shield to set its size and board thickness and see every steel part (boss, grip, back straps, rim, face), the rivets by location with lengths, the weights, build steps and the museum sizes it is based on. Build sheet prints all of it with a 1:1 boss blank template.

## v1.28 (Nov 16, 2026)

Guards: the guard list now looks and works like the Blade Library. Each guard is a row with a thumbnail, its build level (Simple, Intermediate or Complex), its size for your blade, the number of parts and the main stock. Filter by build, search by name, and click a column heading to sort (click again to reverse). Click a guard to open its full drawing, parts table, how-to notes and sources; the Template & stock sheet button is on every row.

## v1.27.1 (Nov 16, 2026)

Handle scales and pins moved from the Guards tab to Blade Refinement, under the editor. Pins sit on the tang of the design you are refining (the refined tang when you have one) and are saved with that design, so they go into your backup file and carry over when you customize a library blade and save it as a new one. The 1:1 pin template and stock sheet print from there.

## v1.27 (Nov 16, 2026)

Guards: 11 more knife guards and bolsters, for 26 in all. Simple: single front bolster, double bolster, integral (forged-in) bolster, half bolster, guardless with a finger choil, and short stub guard. Intermediate: langet guard, bird's-beak guard, block guard, drop quillon and single finger guard. Each is sized to your blade and prints a stock list and 1:1 templates: side and end outlines with the tang slot for bolsters, slab outlines with pin holes, a choil gauge, and front and top outlines for the guards.

## v1.26 (Nov 16, 2026)

Blade Library: Customize this blade. Open any blade's details and click Customize this blade to load it into Blade Refinement, with the original on the left and your copy on the right. Reshape it, name it, and click Save as new blade: it saves as your own design (listed in the library as Custom, with its own spec sheet) and the library blade is unchanged. The name starts as the original's; saved without changing it, or with the box left empty, it saves as "Blade name - custom".

## v1.25 (Nov 16, 2026)

Guards tab: 15 guard and hilt types (straight, curved and S-shaped quillons, Viking short guard, tsuba, knuckle bow, side-ring, clamshell, D-guard, Pappenheimer, swept, basket, cup, half-basket and finger-ring) sized to any library blade or your own design. Each prints a stock list and 1:1 templates with a scale check: outlines with the tang slot, and flat bars with bend marks for the hilts with rings and bows; long parts split across pages. Handle scales and pins: add pins to the tang (a new pin centers), Auto offset spaces two or more evenly, or drag them for custom placement, then print a 1:1 tang and scale template with drill positions and pin stock.

## v1.24 (Nov 16, 2026)

Smooth curves: outlines curve smoothly through your points instead of zig-zagging, in the Design Studio (Smooth button, on for new tracings) and in Blade Refinement (Smooth curves, on by default). Sharp turns like the tip, the shoulder and spine notches stay sharp corners, and in Blade Refinement Sharp corner keeps any point you pick pointed (shown as a square). Drawings, thumbnails, spec sheets, the steel numbers and the blade recommendations all use the smooth outline; your points stay where you put them.

## v1.23 (Nov 16, 2026)

Dagger Jian (double fuller) added (112 in all): a 32 cm double-edged short jian with two fullers on each side, 3.4 cm wide, sized from the T10 folded short jian listing with thickness from antique duanjian. It has the Ground in / Forged in fuller switch.

## v1.22 (Nov 16, 2026)

Sword Cane (shikomizue) added (111 in all): a straight, single-edged blade with no guard, hidden in a walking cane. Sized from a 1060 sword cane listing (50 cm blade, 2.5 cm wide), a Hanwei stick sword and antique shikomizue. Searching cane sword, stick sword or Zatoichi finds it.

## v1.21 (Nov 16, 2026)

Guandao (smooth spine) added (110 in all): the slimmer guandao with one smooth sweep along the spine up to the point and no spine notch, from a Mandarin Mansion southern yanyuedao and a Longquan traditional guandao. The original Guandao keeps the classic spine notch.

## v1.20 (Nov 16, 2026)

Blade Library: click a column heading to sort the list by it (Blade name, Origin, Blade length, Steel needed, Starting billet, Your bar covers or Result). Click again to reverse; an arrow marks the active column. On phones a Sort menu does the same. Your sort is remembered.

## v1.19 (Nov 16, 2026)

Design Studio: Crop the photo. Press Crop, drag a box around the blade (and the ruler, if you use one), and Apply crop. Your scale points and tracing stay on the blade, rotation keeps working after a crop, and Undo crop brings back the full photo.

## v1.18 (Nov 16, 2026)

Design Studio: Rotate the photo to level a crooked blade. Drag on the photo or use the slider while level lines show, turn it 90 degrees, or press Level my trace to straighten it from your traced blade; your points turn with the photo. Hold Shift while dragging or placing a point to keep lines straight: it snaps into line with its neighbors, or to level, plumb or 45 degrees. Shift works in Blade Refinement too. The Or: blade length box stands out with an orange outline and a Needed tag until the design has a scale.

## v1.17.2 (Nov 15, 2026)

Spec sheets for refined designs now give the specs of the refined blade: the drawing, length, tang, widest point, outline area, steel, best starting bars and your-bar fit all come from the refined shape. The as-forged numbers and the steel to grind off are listed under As forged for comparison.

## v1.17.1 (Nov 15, 2026)

Blade Refinement fix: recommended blades no longer flip upside down to fit, which could put the belly on your spine. They keep the cutting edge on the bottom of your tracing, and a new Cutting edge on the Bottom / Top switch covers tracings made upside down.

## v1.17 (Nov 15, 2026)

New Blade Refinement tab. Trace a photo of the blade you are forging in the Design Studio and save it (Then refine it is on by default): it opens with the blade as forged on the left and the same points on the right to refine. Drag points, tap the outline to add one, double-click or Delete to remove one, with Undo and Start over. The steel to grind off is shaded orange, anything outside your forging shows red, and the tiles show the new length, width and how much steel comes off. What this forging could become fits every library blade inside your as-forged outline at its normal size and ranks them by how much of your forging they use; Use as refined shape loads one to fine-tune. Saved refinements print on the design's spec sheet and go into your backup file. My designs rows have a Refine button.

## v1.16.1 (Nov 15, 2026)

Full tang now looks like a full tang: on the thumbnail, the profile drawing and the spec sheet, the tang is drawn as steel with the handle scales and pins on top, so you can see the steel all the way around the handle. Hidden tang keeps the narrow brown tang.

## v1.16 (Nov 15, 2026)

Halberd (16th century) added (109 in all), from early 1500s German halberds in the Met: spike, axe blade, back fluke and two long langets. Hidden tang or Full tang switch added to the Falcata, Kopis, US M1905 Bayonet, Maguro Bocho, Ginunting and Hira-zukuri tanto (17 blades now have it).

## v1.15 (Nov 15, 2026)

Classic Bowie added (108 in all): 10 in clip-point blade, 1 3/4 in wide, 1/4 in spine, with a Hidden tang or Full tang switch. The Hunting Bowie (120 style) note now says it is the slim Buck 120 pattern and points to the Classic Bowie.

## v1.14 (Nov 14, 2026)

12 weapons from the Forged in Fire list (107 in all): Khanda, Nagamaki, Panabas, Katar, Falcata, Zulu Iklwa, Tizona (El Cid's sword), US M1913 Patton Saber, US M1905 Bayonet, Maguro Bocho (tuna knife), Zulu War Axe (isizenze) and Zande Sickle Sword (Boa). Searching zhanmadao, Viking battle axe, okatana or arming sword finds the blades already listed. Passed: Okatana (a katana variant with no set size), Sword of Perseus and Genghis Khan's Sword (legendary, no surviving pieces to measure) and the French Pioneer Sword (no reliable measurements found).

## v1.13 (Nov 14, 2026)

Seven more Chinese weapons (95 in all): Tie Jian (iron mace), Tie Bian (iron whip), Tie Chi (iron ruler), Ge (dagger-axe), Cha (trident fork), Yue Ya Chan (monk's spade) and Chui (melon hammer). Chinese names added so searching hu die dao, zi-wu, jie bian, emei ci, liu xing chui or rope dart finds the blades already listed.

## v1.12.1 (Nov 14, 2026)

Bevel lines panel in the Design Studio: + Add bevel line is always visible, every line is listed with its own Delete button, and each line has a type (primary bevel, secondary bevel, false edge, fuller edge or other) with its own color and dash style on the drawing and spec sheet.

## v1.12 (Nov 14, 2026)

Design Studio step 4: Bevel lines. Click along each grind line (both sides, secondary bevels, a false edge or fuller edges); New bevel line starts the next one. They show dashed on the saved design, in the Blade Library and on the spec sheet, and come back when you reopen the design.

## v1.11.2 (Nov 14, 2026)

Design Studio: no ruler in the photo? Type the blade length (tip to shoulder) to set the scale. Save design and Spec sheet now say exactly what is missing instead of doing nothing.

## v1.11.1 (Nov 14, 2026)

Smaller tracing dots in the Design Studio, and a smaller grab zone so you can place points close together. Touch screens keep a slightly larger zone for fingers.

## v1.11 (Nov 14, 2026)

Hidden tang or Full tang switch on knives and machetes where a full tang makes sense: Clip-point Hunter, Hunting Bowie, Bolo, Kukri, Parang, Latin Machete, Cane Machete, Barong, Golok and Karambit. It updates the steel needed, the drawing, the dimensions and the spec sheet. Your choice is remembered per blade.

## v1.10 (Nov 14, 2026)

Calculator shows 12 blades your bar makes, with thumbnails: the largest first, the smallest last, and 10 recommended picks in between (good use of the steel with the least reshaping). Click any one to open it in the Blade Library.

## v1.9.1 (Nov 14, 2026)

Project notes can be edited on each project card and print on the project's spec sheet.

## v1.9 (Nov 12, 2026)

Backup reminders: a Not backed up bar, a prompt to save a backup file after saving a design, and a warning before closing with unsaved changes.

## v1.8 (Nov 12, 2026)

Tabbed layout (Calculator, My Shop, Design Studio, Blade Library, Guide & Methods). Saved designs appear in the Blade Library marked Custom, with a Custom filter.

## v1.7 (Nov 12, 2026)

23 new weapons (88 in all): Tang, Qijiebian, Yue, Tekko-kagi, Kama, Kunai, Shuriken, Sai, Manriki-gusari, Rapier, Flanged Mace, Military Flail, Horseman's War Hammer, Dane Axe, Winged Spear, Keris, Moro Kris, Badik, Karambit, Rencong, Golok, Ginunting and Klewang.

## v1.6 (Nov 10 to 12, 2026)

Thumbnails of every blade in the list. Full dimensions for the Kogatana, Kaiken, Ko-wakizashi and Bishou.

## v1.5 (Nov 10, 2026)

Oakeshott types X, Xa, XI, XII, XIII, XIIIa, XIV, XV, XVI and XVIII. Fullers: Ground in or Forged in switch with preform width (from Brent's feedback).

## v1.4 (Before Nov 10, 2026)

Realistic outlines for every blade. Closed-outline tracing, grid overlay, saved designs with automatic spec sheets, and a how-to guide. US 1826 Starr Naval Cutlass and Buck 119/120 style knives.

## v1.3 (Before Nov 10, 2026)

My Shop: stock rack with painted IDs, projects with P-numbers, reserved and used bars greyed out, and a demo rack of salvaged steel.

## v1.2 (Before Nov 10, 2026)

Plan from a drawing: trace a photo or graph paper, or import SVG, DXF, STL or OBJ, with a real-size control.

## v1.1 (Before Nov 10, 2026)

Inch fractions, tighter layout, and Suggest a blade through Microsoft Forms.

## v1.0 (Before Nov 10, 2026)

First release: bar stock calculator, blade library with drawings and dimensions, and printable spec sheets.
